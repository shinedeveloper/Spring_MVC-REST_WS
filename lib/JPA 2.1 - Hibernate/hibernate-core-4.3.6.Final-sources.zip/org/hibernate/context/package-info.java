/**
 * Defines support for "current session" feature.
 */
package org.hibernate.context;
