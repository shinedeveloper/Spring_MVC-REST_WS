/**
 * Package containing all the Hibernate specific annotations.
 */
package org.hibernate.annotations;
