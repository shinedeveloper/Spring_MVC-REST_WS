/**
 * Internals for action processing.
 */
package org.hibernate.action.internal;
