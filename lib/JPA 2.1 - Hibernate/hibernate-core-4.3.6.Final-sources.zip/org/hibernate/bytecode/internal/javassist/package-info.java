/**
 * Javassist support internals
 */
package org.hibernate.bytecode.internal.javassist;
