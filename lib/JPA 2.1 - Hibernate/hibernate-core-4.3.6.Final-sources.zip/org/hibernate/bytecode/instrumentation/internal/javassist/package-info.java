/**
 * Javassist support internals
 */
package org.hibernate.bytecode.instrumentation.internal.javassist;
