/**
 * Bytecode instrumentation internals
 */
package org.hibernate.bytecode.instrumentation.internal;
