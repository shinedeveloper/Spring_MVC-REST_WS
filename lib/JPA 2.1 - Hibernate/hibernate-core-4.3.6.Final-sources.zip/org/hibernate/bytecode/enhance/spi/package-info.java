/**
 * Package defining bytecode code enhancement (instrumentation) support.
 */
package org.hibernate.bytecode.enhance.spi;
