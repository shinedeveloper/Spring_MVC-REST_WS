/**
 * Package defining build-time bytecode code enhancement (instrumentation) support.
 *
 * This package should mostly be considered deprecated in favor of {@link org.hibernate.bytecode.enhance}
 */
package org.hibernate.bytecode.buildtime.spi;
