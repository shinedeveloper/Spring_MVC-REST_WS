/**
 * Javassist support internals
 */
package org.hibernate.bytecode.buildtime.internal;
