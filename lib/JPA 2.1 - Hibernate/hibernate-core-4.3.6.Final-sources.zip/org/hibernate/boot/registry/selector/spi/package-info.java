/**
 * Defines actual contract used for strategy selection : {@link StrategySelector}.
 */
package org.hibernate.boot.registry.selector.spi;
