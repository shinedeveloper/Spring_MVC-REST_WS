package net.sevecek.util.swing;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class JKeyboard extends JComponent {

    private Map<Integer, Boolean> keys = new HashMap<Integer, Boolean>();

    public JKeyboard() {
        setSize(40, 30);
        setMaximumSize(getSize());
        setPreferredSize(getSize());
        setMinimumSize(getSize());
        setFocusable(true);
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }


            @Override
            public void keyPressed(KeyEvent e) {
                keys.put(e.getKeyCode(), Boolean.TRUE);
            }


            @Override
            public void keyReleased(KeyEvent e) {
                keys.put(e.getKeyCode(), Boolean.FALSE);
            }
        });
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
            }

            @Override
            public void focusLost(FocusEvent e) {
                keys.clear();
            }
        });
    }


    public boolean isKeyDown(int key) {
        Boolean state = keys.get(key);
        return state != null && state.booleanValue();
    }

}
